# Test Rule 2

This is a test rule content.