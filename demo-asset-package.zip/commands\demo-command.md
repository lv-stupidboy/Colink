# Demo Command

这是一个演示命令，用于测试资产包功能。

## 使用场景

当你需要快速生成项目骨架时，使用此命令。

## 参数

- `project_name`: 项目名称
- `template`: 模板类型 (web/api/cli)

## 示例

```
/create-project --name myapp --template web
```