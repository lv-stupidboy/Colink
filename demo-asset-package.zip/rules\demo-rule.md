# Demo Rule

## 代码规范

### 命名规范

- 变量名使用 camelCase
- 常量名使用 UPPER_SNAKE_CASE
- 函数名使用 camelCase
- 类名使用 PascalCase

### 注释规范

- 公共函数必须有注释
- 复杂逻辑需要行内注释
- 使用中文注释

### 文件规范

- 一个文件一个主要类/函数
- 文件名使用 snake_case
- 文件头部添加版权声明